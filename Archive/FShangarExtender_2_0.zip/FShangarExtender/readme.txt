Hangar Extender
by Snjo

This plugin extends the usable area when building in the SPH or VAB, so you can build outside or above the building. Useful for building large aircraft carriers or tall rockets.
InfiniteDice's Boat Parts mod has it's own version of this moudle, so you will not need this if you are also using his mod.

License:
Creative Commons Attribution 4.0 International.

If you need a bigger model of the SPH, press Numpad * to scale it up x5. This key can be rebound in settings.txt.
Use values like a, b, c, page up, [1] (for numpad 1). See more here: https://docs.unity3d.com/Documentation/Manual/Input.html

There is no building scaling in the SPH yet, but the work area is of course extended there as well.

This mod also extends the work/camera area if you are using a 6DOF device (Space Navigator)

Source: https://github.com/snjo/FShangarExtender