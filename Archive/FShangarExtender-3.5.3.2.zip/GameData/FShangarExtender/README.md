Some people like to build huge vessels.  This mod extends the hanger to allow you to do so.

